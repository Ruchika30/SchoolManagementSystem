<?php
//Variables
$name = $_POST['name'];
$roll = $_POST['roll'];
$class  = $_POST['divclass'];

/*
In simple terms, we are using the name="" attribute from the <input> tags to define the php variables, to change this to a get method, change POST to GET (case sensitive) and to add new ones use the syntax, $var = $_POST['inputname'];
*/
 
//Connect to DB
$conn=mysqli_connect("localhost","root","","db");
            if (mysqli_connect_errno()) { 
                echo "Failed to connect to MySQL: " . mysqli_connect_error(); 
            };

//Insert Values
$sql = "INSERT INTO details(name, roll, class)
	VALUES ('$name', '$roll','$class')";

 
if ($conn->query($sql) === TRUE) {
    echo "New  	record created successfully";
} else {
    //Change this to for a custom error message
    echo  	"Error: " . $sql . "<br>" . $conn->error;
}
 
 
//Another example might be mail to the owner
 
 
?>