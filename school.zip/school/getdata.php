<?php 
$conn=mysqli_connect("localhost","root","","db"); 
// Check connection 
if (mysqli_connect_errno()) 
  { 
  echo "Failed to connect to MySQL: " . mysqli_connect_error(); 
  } 

$result = mysqli_query($conn,"SELECT * FROM details"); 

echo "<table border='1'> 
<tr> 
<th>Name</th> 
<th>RollNo</th> 
<th>Division</th> 
</tr>"; 

while($row = mysqli_fetch_array($result)) 
  { 
            echo "<tr>"; 
        echo "<td>" . $row['name'] . "</td>"; 
        echo "<td>" . $row['roll'] . "</td>"; 
        echo "<td>" . $row['class'] . "</td>"; 
      //  echo "<td>" . "<a href='row_test.php'>Post</a>". "</td>"; 
        echo "</tr>"; 
  } 
echo "</table>"; 

mysqli_close($conn); 
?>